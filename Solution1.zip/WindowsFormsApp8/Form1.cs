﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e) {
            switch (e.KeyCode) {
                case Keys.Up:
                    panel1.BackColor = Color.Aqua;
                    break;
                case Keys.Down:
                    panel1.BackColor = Color.Orange;
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e) {
            panel1.BackColor = Color.White;
        }
    }
}