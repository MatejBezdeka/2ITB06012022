﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }
        
        
        private void Form1_MouseClick(object sender, MouseEventArgs e) {
            int x = Cursor.Position.X;
            int y = Cursor.Position.Y;
            label3.Text = x.ToString();
            label4.Text = y.ToString();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e) {
            int x = Cursor.Position.X;
            int y = Cursor.Position.Y;
            label1.Text = x.ToString();
            label2.Text = y.ToString();
        }
    }
}