﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10 {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e) {
            switch (e.KeyCode) {
                case Keys.W:
                    panel1.Top -= 10; 
                    break;
                case Keys.S:
                    panel1.Top += 10;
                    break;
                case Keys.A:
                    panel1.Left -= 10;
                    break;
                case Keys.D:
                    panel1.Left += 10;
                    break;
            }
        }
    }
}